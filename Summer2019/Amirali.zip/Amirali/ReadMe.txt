In addition to the previous training files I sent. This training file attached adds a few more appliances.

So here's all of Amir's appliances:

1. Stove
2. Microwave
3. Vent
4. Fridge
5. Coffe Maker
6. Cooker
7. Black small printer
8. White large printer
9. standing lamp next to the printer
10. TV
11. Lamp on Amir's desk
12. Standing lamp by Amir's desk

-------------------------------------

During the processing, some the pictures went blurry or the camera came off balance due to the right ir led getting heated. So not all the pictures taken may be usable.

 